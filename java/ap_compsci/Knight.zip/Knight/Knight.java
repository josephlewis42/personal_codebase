import java.util.*;
/**
 * Class Knight, emulates a knight on a board
 * First is col, next is row
 * 
 * @author Joseph Lewis
 * @version Feb. 4 2010
 */
public class Knight
{
    //the number of moves
    protected int numMoves = 0;
    //The game board
    protected int board[][] = new int[8][8];
    public int col = 0;
    public int row = 0;
    
    /**
     * Constructor for objects of class Knight
     */
    public Knight()
    {
        //If you can move, by default you can
        boolean canMove = true;
        //Continue moving as long as possible
        while(canMove)
        {
            //Advance counter
            numMoves++;
            //Set the knight's Location to the move number
            board[col][row] = numMoves;
            
            canMove = chooseMove(getPossibleLocations());
        }
        //Print the board later
        printOutput();

    }

    /**
     * Outputs the board
     */
    public void  printOutput()
    {
        //Print a new line
        System.out.println("");
        //For each row
        for(int i = 0; i < 8; i++)
        {
            //In each col
            for(int j = 0; j < 8; j++)
            {
                //Print contents
                System.out.printf("%3d", board[j][i]);
            }
            //Print a new line at the end of a row
            System.out.print("\n");
        }
        //Print total moves
        System.out.println("\n Total Moves --> "+numMoves);
        System.out.println("========================");
        //System.out.println("Col => "+ col + " Row => " + row);
    }
    
    /**
     * Get the locations the knight can move to
     */
    public ArrayList<Location> getPossibleLocations()
    {
        return getPossibleLocations(new Location(row,col));
    }
    
    public ArrayList<Location> getPossibleLocations(Location l)
    {
        //List to hold all valid locations
        ArrayList<Location> loc = new ArrayList<Location>();
        //Populate the list
        loc.add(new Location(row + 1,col - 2));
        loc.add(new Location(row + 1,col + 2));
        loc.add(new Location(row - 1,col - 2));
        loc.add(new Location(row - 1,col + 2));
        loc.add(new Location(row + 2,col + 1));
        loc.add(new Location(row + 2,col - 1));
        loc.add(new Location(row - 2,col + 1));
        loc.add(new Location(row - 2,col - 1));

        for(int i = loc.size() - 1; i >= 0; i--)
        {
            if(!isValid(loc.get(i)))
            {
                loc.remove(i);
            }
        }
        
        return loc;
    }
    
    /**
     * Choose the move location
     */
    public boolean chooseMove(ArrayList<Location> list)
    {
        Location locChose;
        //If no more places to go, quit
        if(list.size() == 0)
        {
            return false;
        }

        //Make a random generator
        Random generator = new Random();
        //Choose an element of list
        int choose = generator.nextInt(list.size());
        //System.out.println("Chosen Int => "+choose); //Testing
        //Set the values of the chosen 
        locChose = list.get(choose);
        
        //Move the knight
        move(locChose);
        return true;
    }
    
    /**
     * Moves the player
     */
    public void move(Location loc)
    {
        //Set new col
        col = loc.col;
        //Set new row
        row = loc.row;
        //System.out.println("New Col => "+col+" Row => "+row); //Testing
    }
    
    /**
     * Checks if the location is valid
     */
    public boolean isValid(Location loc)
    {
        //If location is on the board and not chosen
        if(loc.col > 7 || loc.col < 0 || loc.row > 7 || loc.row < 0 || board[loc.col][loc.row] != 0)
            return false;
        else
            return true;
    }
}