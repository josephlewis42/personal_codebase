public class KnightDriver
{
	public static void main(String[] args)
	{
	    Knight k = new Knight();
	}
}
