import java.util.*;
/**
 * Makes a smarter Knight
 * 
 * @author Joseph Lewis
 */
public class KnightII extends Knight
{
    /**
     * Constructor for objects of class Knight
     */
    public KnightII()
    {
        //If you can move, by default you can
        boolean canMove = true;
        //Continue moving as long as possible
        while(canMove)
        {
            //Advance counter
            numMoves++;
            //Set the knight's Location to the move number
            board[col][row] = numMoves;
            
            canMove = chooseMove(getPossibleLocations());
        }
        //Print the board later
        printOutput();
    }
    /**
     * chooses the move based on the possible locations
     */
    public boolean chooseMove(ArrayList<Location> list)
    {
        //Set the num of locations avalable to the knight
        for(Location l : list)
        {
            l.locations = getPossibleLocations(l).size();
        }
        Location locChose;
        
        //If no more places to go, quit
        if(list.size() == 0)
        {
            return false;
        }
        //Find the location with the fewest places to go.
        int smallestNum = 20;
        for(Location l : list)
        {
            if(l.locations < smallestNum)
            {
                smallestNum = l.locations;
            }
        }
        //Remove all but the ones with the smallest
        for(int i = list.size() - 1; i >= 0; i--)
        {
            if(list.get(i).locations != smallestNum)
            {
                list.remove(i);
            }
        }
        //Make a random generator
        Random generator = new Random();
        //Choose an element of list
        int choose = generator.nextInt(list.size());
        //System.out.println("Chosen Int => "+choose); //Testing
        //Set the values of the chosen 
        locChose = list.get(choose);
        
        //Move the knight
        move(locChose);
        return true;
    }
}
