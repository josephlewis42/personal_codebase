public class KnightIIDriver
{
	public static void main(String[] args)
	{
	    KnightII k = new KnightII();
	}
}
