/**
 * Location holds a location
 * 
 * @author Joseph Lewis
 * @version Feb. 8, 2010
 */
public class Location
{
    public int row;
    public int col;
    public int locations;

    /**
     * Constructor for objects of class Location
     */
    public Location(int myRow, int myCol)
    {
        row = myRow;
        col = myCol;
    }
    public Location(int myRow, int myCol, int myLocations)
    {
        row = myRow;
        col = myCol;
        locations = myLocations;
    }
    
    public String toString()
    {
        return ("Location at col: "+col+" row "+row);
    }
}