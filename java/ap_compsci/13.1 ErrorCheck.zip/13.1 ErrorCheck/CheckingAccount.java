/**
 * Joseph Lewis
 */
public class CheckingAccount{
  private double myBalance;
  private int myAccountNumber;

  public CheckingAccount(){
    myBalance = 0.0;
    myAccountNumber = 0;
  }

  public CheckingAccount(double initialBalance, int acctNum){
    //Throw Exception if initial balance is negative
      if(initialBalance < 0)
    {
        throw new IllegalArgumentException();
    }
    myBalance = initialBalance;
    myAccountNumber = acctNum;
   }

  public double getBalance(){
    return myBalance;
  }

  public void deposit(double amount){
    //Throw Exception if depositing negative
      if(amount < 0)
    {
        throw new IllegalArgumentException();
    }
      myBalance += amount;
  }

  public void withdraw( double amount ){
    //Throw Exception if overdrawn
      if(myBalance-amount < 0)
    {
        throw new IllegalArgumentException();
    }
    myBalance -= amount;
  }
}