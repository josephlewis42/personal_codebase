/**
 * A test class for the program
 * 
 * @author Joseph Lewis 
 * @version Jan 6, 2010
 */
public class OldMcDonald
{
  public static void main(String[] args)
  {
    System.out.println(">>Testing Animals");
    Cow c = new Cow();
    System.out.println( c.getType() + " goes " + c.getSound() );
    
    Pig p = new Pig();
    System.out.println( p.getType() + " goes " + p.getSound() );
    
    Chick h = new Chick(true);
    System.out.println( h.getType() + " goes " + h.getSound() );
    System.out.println( h.getType() + " also goes " + h.getSound() );
    
    System.out.println("\n\nFour legs good, Two legs bad\n\n");
    System.out.println(">>Testing Farm");
    Farm f = new Farm();
    f.animalSounds();
  }
}