
/**
 * Adds a name to a cow
 * 
 * @author Joseph Lewis
 * @version Jan 6, 2010
 */
public class NamedCow extends Cow
{
    private String name;

    /**
     * Names the cow
     */
    public NamedCow(String myName)
    {
        name = myName;
    }
 
    public String getName()
    {
        return name;
    }
}
