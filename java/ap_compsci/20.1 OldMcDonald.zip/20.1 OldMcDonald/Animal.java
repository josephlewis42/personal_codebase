/**
 * An interface describing animals.
 * 
 * @author Joseph Lewis 
 * @version Jan 6, 2010
 */

public interface Animal
{
  public String getSound();
  public String getType();
}