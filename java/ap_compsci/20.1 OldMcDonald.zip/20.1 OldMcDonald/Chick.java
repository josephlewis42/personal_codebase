/**
 * A chick type
 * 
 * @author Joseph Lewis 
 * @version Jan 6, 2010
 */

public class Chick implements Animal
{
  private String myType;
  private String mySound;
  private String myGrownSound;
  private boolean twoSounds = false;
  private boolean soundOne = true;

  Chick()
  {
    myType = "chick";
    mySound = "cheep";
    myGrownSound = "cluck";
  }
  /**
   * Checks if the user wants two sounds with their animal
   */
  Chick(boolean myTwoSounds)
  {
    this();
    twoSounds = myTwoSounds;
  }

  public String getSound()
  {
      String sound = mySound;
      //If two sounds flag set
      if(twoSounds)
      {
          //Return sound the sound
          sound = (soundOne) ? mySound : myGrownSound;
          //Flip the flag, so the other plays
          soundOne = !soundOne;
      }
    return sound;
  }

  public String getType()
  {
    return myType;
  }
}