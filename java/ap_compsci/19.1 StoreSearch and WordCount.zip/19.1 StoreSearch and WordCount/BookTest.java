public class BookTest
{
    public static void Main(String[] args)
    {
        new Book("dream.txt");
        new Book("Lincoln.txt");
        //new Book("test.txt");
    }
}
