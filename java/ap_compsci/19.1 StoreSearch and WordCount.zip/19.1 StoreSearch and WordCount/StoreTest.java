public class StoreTest
{
    public static void Main(String[] args)
    {
        System.out.println(">>Loading File");
        Store st = new Store("file50.txt");
        System.out.println(">>Testing ToString Method");
        System.out.println(st.toString());
        System.out.println(">>Testing Sort Method");
        st.Sort();
        System.out.println(">>Testing displayStore Method");
        st.displayStore();
        System.out.println(">>Testing search algorythm in text mode.");
        st.textSearch();
    }
}
