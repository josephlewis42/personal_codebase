public class ItemTest
{
    public static void Main(String[] args)
    {
        //User
        System.out.println(">>Starting Test");
        System.out.println(">>Creating item with id = 30, inv = 60");
        Item a = new Item(30,60);
        System.out.println(">>Testing To String Method");
        System.out.println(a.toString());
        System.out.println(">>Creating item with id = 40, inv = 60");
        Item b = new Item(40,60);
        System.out.println(">>Comparing Item One To Two");
        System.out.println(a.compareTo(b));
        System.out.println(">>Comparing Item Two To One");
        System.out.println(b.compareTo(a));
        System.out.println(">>Comparing Item One To One");
        System.out.println(a.compareTo(a));
        System.out.println(">>Testing Equals Method Item One To One");
        System.out.println(a.equals(a));
        System.out.println(">>Testing Equals Method Item One To Two");
        System.out.println(a.equals(b));
        
        //System
        boolean pass = true;
        if(!a.toString().equals("ID: 30 Inventory: 60"))
            pass = false;
        if(a.compareTo(b) != -10)
            pass = false;
        if(b.compareTo(a) != 10)
            pass = false;
        if(a.compareTo(a) != 0)
            pass = false;
        if(a.equals(a) != true)
            pass = false;
        if(a.equals(b) != false)
            pass = false;
        
        System.out.println(">>It is "+pass+" that the test worked.");
    }
}
