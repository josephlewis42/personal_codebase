public class Item{
  private int myId;
  private int myInv;

  public Item(int id, int inv){
    myId = id;
    myInv = inv;
  }

  /**
   * Get Methods
   */
  public int getId(){return myId;}
  public int getInv(){return myInv;}

  /**
   * Compares the two objects based on id
   */
  public int compareTo(Item other)
  { 
    int value = 0;
    int oth = other.getId();
    
    if(oth > myId)
        value = -10;
    if(oth < myId)
        value = 10;
    if(oth == myId)
        value = 0;
        
    return value;
  }

  /**
   * Compares two objects, returns true if
   * all variables are equal
   */
  public boolean equals(Item other)
  { 
      boolean equals = true;
      if(myId != other.getId())
        equals = false;
      if(myInv != other.getInv())
        equals = false;
        
    return equals;
  }

  /**
   * Returns a string value for the object.
   */
  public String toString()
  {
    return "ID: "+ myId + " Inventory: " + myInv;
  }
}

