public class Word{
  private String word;
  private int numWords;

  public Word(String myWord)
  {
    word = myWord;
  }

  /**
   * Get Methods
   */
  public String getWord(){return word;}
  public void addWord(){numWords++;}
  public int getNumWords(){return numWords;}

  /**
   * Compares the two objects based on word
   */
  public int compareTo(Word other)
  { 
    int value = 0;
    String oth = other.getWord();
    
    //If other is greater
    if(oth.compareTo(word) > 0)
        value = -10;
    //If this is greater
    if(oth.compareTo(word) < 0)
        value = 10;
    //If they are equal
    if(oth.compareTo(word) == 0)
        value = 0;
        
    return value;
  }
  
  /**
   * Compares the two objects based on word
   */
  public int compareNumTo(Word other)
  { 
    int value = 0;
    int oth = other.getNumWords();
    
    //If other is greater
    if(oth > numWords)
        value = -10;
    //If this is greater
    if(oth < numWords)
        value = 10;
    //If they are equal
    if(oth == numWords)
        value = 0;
        
    return value;
  }

  /**
   * Compares two objects, returns true if
   * all variables are equal
   */
  public boolean equals(Word other)
  { 
    return word.equals(other);
  }

  /**
   * Returns a string value for the object.
   */
  public String toString()
  {
    return word;
  }
}