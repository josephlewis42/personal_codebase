import java.util.*;
import java.io.*; //File Reading and Writing
import java.lang.Integer;


/**
 * Mimics a store (A container for objects of type item).
 * 
 * @author Joseph Lewis 
 * @version Dec 30, 2009
 */
public class Store
{
    static int RIGHT = 1;
    static int LEFT = 2;
    
    private ArrayList <Item> myStore = new ArrayList <Item>();
    /**
     * Constructor for objects of class Store2
     */
    public Store(String myFileName)
    {
        loadFile(myFileName);
    }
    public Store()
    {
        
    }

    /**
     * Loads a file as type Items
     * 
     * @param  path, The location of the file
     * @return Nothing, loads the store
     */
    public void loadFile(String path)
    {
        try
        {
            String line = "";
            //Start the file reader for the document, then buffer it
            FileReader fileReader = new FileReader(path);
            BufferedReader br = new BufferedReader(fileReader);
            
            while(line != null)
            {
                //Read the line from the file
                line = br.readLine();
                if(line != null)
                {
                    line = line.trim();
                    //Split the line up into two number segments, the first is the id
                    //The second is the inventory
                    String[] tempStr = line.split("\\s+",2);
                    int id = Integer.parseInt(tempStr[0]);
                    int inventory = Integer.parseInt(tempStr[1]);
                    //Make an item
                    Item it = new Item(id,inventory);
                    myStore.add(it);
                } 
            }
            br.close();
        }
        catch(java.io.FileNotFoundException e){System.err.println("FileNotFound");}
        catch(java.io.IOException e){System.err.println("I/O Error");}
    }
    
    /**
     * Prints out the stores contents
     */
    public void displayStore()
    {
        int lines = 0;
        System.out.println("\tID: \tNum in Inventory:");
        for(Item i : myStore)
        {
            lines++;
            System.out.println(lines + "\t" + i.getId() + "\t" + i.getInv());
            //Every ten lines print a blank one
            if(lines % 10 == 0)
            {
                System.out.println();
            }
        }
    }
    
    /**
     * Returns the string value of the class
     */
    public String toString()
    {
        String s = "";
        s += "\tID: \tNum in Inventory:";
        
        for(Item i : myStore)
        {
            s += "\n\t " + i.getId() + "\t " + i.getInv();
        }
        return s;
    }
    
    /**
     * Sorts the items.
     */
    public void Sort()
    {
        myStore = mergeSort(myStore);
    }
    
    /**
     * Taken From 18.1 Quad Sort
     */
  private ArrayList<Item> merge(ArrayList<Item> left, ArrayList<Item> right)
  {
    ArrayList<Item> result = new ArrayList<Item>();
    //For each array part
    while (left.size() > 0 && right.size() > 0)
    {
        Item leftNum = left.get(0);
        Item rightNum = right.get(0);
        //Add the num to the result
        if(leftNum.compareTo(rightNum) <= 0)
        {
            result.add(leftNum);
            left.remove(0);
        }
        else
        {
            result.add(rightNum);
            right.remove(0);
        }
    }
    if(left.size() > 0)
    {
        result.addAll(left);
    }
    else
    {
        result.addAll(right);
    }
    return result;
  }

  /**
   *  Recursive mergesort of an array of integers
   */
  public ArrayList<Item> mergeSort(ArrayList<Item> list)
  {
      ArrayList<Item> left, right, result;
      int middle = list.size() / 2;
      if(list.size() <= 1)
      {
          return list;
      }
      left  = getRange(list, LEFT);
      right = getRange(list, RIGHT);
      left = mergeSort(left);
      right = mergeSort(right);
      list = merge(left,right);
      return list;
  }
  
   /**
    * Removes a range in an array list
    *
    * @param  list refrence to the array list
    * @param  dir  UP if removing top half, DOWN to remove bottom half
    */
   public ArrayList<Item> getRange(ArrayList<Item> list, int dir)
   {
       ArrayList<Item> leftList = new ArrayList<Item>();
       ArrayList<Item> rightList = new ArrayList<Item>();
       final int low  = 0;
       final int high = list.size() - 1;
       final int mid  = list.size() / 2;
       //Get first half of array
       for(int i = low; i < mid; i++)
       {
           leftList.add(list.get(i));
       }
       //Get second half of array
       for(int i = mid; i <= high; i++)
       {
           rightList.add(list.get(i));
       }
       if(LEFT == dir)
       {
           return leftList;
       }
       else
       {
           return rightList;
       }
   }
   
   /**
   * Searches the specified ArrayList of Item Objects for the specified
   * id using a recursive binary search algorithm
   *
   * @param idToSearch Id value being search for
   * @param first Starting index of search range
   * @param last Ending index of search range
   * @return index of Item if found, -1 if not found
   */

  private int bsearch(Item idToSearch, int first, int last)
  {
      int midPoint = first + ((last - first) / 2);
      Item mid = myStore.get(midPoint);
      
      //If ran out of items
      if (last == first || midPoint == first || midPoint == last)
      {
          return -1;
      }
      //If middle is higher
      if (idToSearch.compareTo(mid) < 0)
      {
          //Search Lower half
          return bsearch(idToSearch, first, midPoint);
      }
      //If middle is lower
      if (idToSearch.compareTo(mid) > 0)
      {
          //Search higher half
          return bsearch(idToSearch, midPoint, last);
      }
      //If they are equal
      if (mid.compareTo(idToSearch) == 0)
      {
          //Return the middle
          return midPoint;
      }
      return -1;
  }
  
  /**
   * Test search
   */
  public void textSearch(){
   int idToFind;
   int invReturn;
   int index;
   Scanner in = new Scanner(System.in);
   do{
      System.out.println();
      System.out.print("Enter Id value to search for (-1 to quit) ---> ");
      idToFind = in.nextInt();
      //index = bsearch(new Item(idToFind, 0));
      //recursive version call
      index = bsearch (new Item(idToFind, 0), 0, myStore.size()-1);
      System.out.print("Id # " + idToFind);
      if (index == -1){
         System.out.println(" No such part in stock");
      }else{
         System.out.println(" Inventory = " + myStore.get(index).getInv());
      }
   } while (idToFind >= 0);
}


}
