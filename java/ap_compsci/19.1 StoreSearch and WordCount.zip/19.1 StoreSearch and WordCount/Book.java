import java.util.*;
import java.io.*; //File Reading and Writing

/**
 * Mimics a book (A container for objects of type word).
 * 
 * @author Joseph Lewis 
 * @version Dec 30, 2009
 */
public class Book
{
    static int RIGHT = 1;
    static int LEFT = 2;
    ArrayList<String> allWords = new ArrayList<String>();
    
    private ArrayList <Word> myBook = new ArrayList <Word>();
    /**
     * Constructor for objects of class Store2
     */
    public Book(String myFileName)
    {
        loadFile(myFileName);
        Sort();
        combineAllWords();
        
        myBook = bubbleSort(myBook);
        
        int a = 0;
        for(int i = myBook.size() - 1; a < 30; i--)
        {
            a++;
            Word w = myBook.get(i);
            System.out.println(w.getWord() + "\t\t" + w.getNumWords());
        }
    }

    /**
     * Combines words into a list of words
     */
    public void combineAllWords()
    {
        String checkWord = "";
        
        myBook.add(0,new Word(checkWord));
        myBook.get(0).addWord();
        
        for(String s : allWords)
        {
            if (!s.equals(checkWord))
            {
                checkWord = s;
                Word w = new Word(s);
                myBook.add(0,w);
                myBook.get(0).addWord();
            }
            else 
            {
                myBook.get(0).addWord();
            }
        }
        
    }
    
  /**
   *  Bubble Sort is the slowest but easiest sort The Bubble Sort 
   *  gets its name from the way that the largest items �bubble� 
   *  to the top (end). The procedure goes like this.
   *
   * @param  list  reference to an array of integers to be sorted
   */
  public ArrayList<Word> bubbleSort(ArrayList <Word> list)
  {
      //The number of total comparisons is the size - 1
      final int numOfComparisons = list.size() - 1;
      //The number of comparisons with no chane of number
      int numOkayComparisons = 0;
      
      Object currentNumber;
      Object nextNumber;
      
      do
      {
         //Assume all comparisons are good 
         numOkayComparisons = numOfComparisons;
            
          for(int i = 0; i < numOfComparisons; i++)
            {
              //If the current number is larger swap them
              if( list.get(i).compareNumTo(list.get(i + 1)) > 0)
                {
                  //Add the first to after the second
                  list.add(i + 2, list.get(i));
                  //Delete the first
                  list.remove(i);
                  //Tell the sorter it must run again
                  numOkayComparisons--;
                }
            }
        }
        //Done when the number of comparisons is the same as those that passed
        while(numOfComparisons != numOkayComparisons);
        
        return list;
  }

    /**
     * Loads a file as type Word
     * 
     * @param  path, The location of the file
     * @return Nothing, loads the book
     */
    private void loadFile(String path)
    {
        try
        {
            String line = "";
            //Start the file reader for the document, then buffer it
            FileReader fileReader = new FileReader(path);
            BufferedReader br = new BufferedReader(fileReader);
            
            while(line != null)
            {
                //Read the line from the file
                line = br.readLine();
                if(line != null)
                {
                    System.out.println(line);
                    //Remove leading and trailing whitespace
                    line = line.trim();
                    //Upper case all words
                    line = line.toUpperCase();
                    //Replace dashes with space around them
                    line = line.replaceAll(" - ", " ");
                    //Replace all special characters with nothing, keeping spaces
                    line = line.replaceAll("[^a-zA-Z0-9\\s-]", "");
                    //Split the line up into two number segments, the first is the id
                    //The second is the inventory
                    String[] tempStr = line.split("\\s+");
                    
                    for(String s : tempStr)
                        allWords.add(s);
                } 
            }
            br.close();
        }
        catch(java.io.FileNotFoundException e){System.err.println("FileNotFound");}
        catch(java.io.IOException e){System.err.println("I/O Error");}
    }
    
    
    /**
     * Sorts the items.
     */
    public void Sort()
    {
        allWords = mergeSort(allWords);
    }
    
    /**
     * Taken From 18.1 Quad Sort
     */
  private ArrayList<String> merge(ArrayList<String> left, ArrayList<String> right)
  {
    ArrayList<String> result = new ArrayList<String>();
    //For each array part
    while (left.size() > 0 && right.size() > 0)
    {
        String leftNum = left.get(0);
        String rightNum = right.get(0);
        //Add the num to the result
        if(leftNum.compareTo(rightNum) <= 0)
        {
            result.add(leftNum);
            left.remove(0);
        }
        else
        {
            result.add(rightNum);
            right.remove(0);
        }
    }
    if(left.size() > 0)
    {
        result.addAll(left);
    }
    else
    {
        result.addAll(right);
    }
    return result;
  }

  /**
   *  Recursive mergesort of an array of integers
   */
  public ArrayList<String> mergeSort(ArrayList<String> list)
  {
      ArrayList<String> left, right, result;
      int middle = list.size() / 2;
      if(list.size() <= 1)
      {
          return list;
      }
      left  = getRange(list, LEFT);
      right = getRange(list, RIGHT);
      left = mergeSort(left);
      right = mergeSort(right);
      list = merge(left,right);
      return list;
  }
  
   /**
    * Removes a range in an array list
    *
    * @param  list refrence to the array list
    * @param  dir  UP if removing top half, DOWN to remove bottom half
    */
   public ArrayList<String> getRange(ArrayList<String> list, int dir)
   {
       ArrayList<String> leftList = new ArrayList<String>();
       ArrayList<String> rightList = new ArrayList<String>();
       final int low  = 0;
       final int high = list.size() - 1;
       final int mid  = list.size() / 2;
       //Get first half of array
       for(int i = low; i < mid; i++)
       {
           leftList.add(list.get(i));
       }
       //Get second half of array
       for(int i = mid; i <= high; i++)
       {
           rightList.add(list.get(i));
       }
       if(LEFT == dir)
       {
           return leftList;
       }
       else
       {
           return rightList;
       }
   }    
}