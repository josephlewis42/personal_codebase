import java.lang.Math;
/**
 * Rolling provides a place for dice to be rolled and computed
 * 
 * @author Joseph Lewis
 * @version October 20, 2009
 */
public class Rolling
{
    private int dieOne, dieTwo, dieThree;
    private int count = 0;

    /**
     * Constructor for objects of class Rolling
     */
    public Rolling()
    {
    }

    /**
     * Roll - Rolls the dice and outputs the result, untill all 
     * are different.
     */
    public void roll()
    {
        //Roll the dice while the ddice equal each other
        do
        {
            //Get the dice values
            dieOne   = rollDie(); 
            dieTwo   = rollDie();
            dieThree = rollDie();
            //Print them out for the user
            System.out.println(dieOne+ " " +dieTwo + " " +dieThree);
            //Add one to the count
            count++;
            
        }while((dieOne != dieTwo) && (dieOne != dieThree)
                                            && (dieTwo != dieThree));
                                            
        System.out.println("Count = "+count);
    }
    
    /**
     * rollDie - rolls one die and returns the value
     * @return int 1-6
     */
    private int rollDie()
    {
        //Return a random int from 1-6
        return (int) (6 * Math.random());
    }
}
