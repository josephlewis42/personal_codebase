
/**
 * Fibonacci creates a fibonacci number sequence
 * 
 * @author Joseph Lewis 
 * @version Sep 9 09
 */
import java.util.Scanner;   //System.in

public class Fibonacci
{
    private int iteration, lastValue, beforeLastValue, totalIterations;

    /**
     * Constructor for objects of class Fibonacci
     */
    public Fibonacci()
    {
        Scanner in = new Scanner(System.in);
        do
        {
            System.out.println("Enter the number of iterations:");
            iteration = in.nextInt();
            totalIterations = iteration;
        }while(iteration < 0);
        
        //Set first numbers
        lastValue = 1;
        beforeLastValue = 2;
        
        sequence(lastValue,beforeLastValue);
    }

    /**
     * Sequence
     * 
     * @param  lastValue, the value of the last number
     * @param  beforeLastVal, the value before last
     */
    public void sequence(int myLastValue, int myBeforeLastVal)
    {
        //Set Vars
        beforeLastValue = myBeforeLastVal;
        lastValue = myLastValue;
        
        
        int a;
        //Tell the program it is one step further
        iteration --;
        
        
        //Set A to be the current Fibonacci number
        a = lastValue * beforeLastValue;
        System.out.println("Iteration "+(totalIterations-iteration)+" = "+a);
        //Set the variables properly
        beforeLastValue = lastValue;
        lastValue = a;
        
        //As long as the program still wants to go on continue
        if(!(iteration <= 0))
        {
            sequence(lastValue, beforeLastValue);
        }
    }
}
