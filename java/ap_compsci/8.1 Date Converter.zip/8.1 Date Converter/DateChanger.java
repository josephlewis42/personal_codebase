
/**
 * Write a description of class DateChanger here.
 * 
 * @author Joseph Lewis 
 * @version Sep 9, 09
 */
import java.lang.Integer;   //Conversion
import java.util.Scanner;   //System.in


public class DateChanger
{
    private int     date;
    private String  month;
    private int     day,year;

    /**
     * Constructor for objects of class DateChanger
     */
    public DateChanger()
    {
        getUserInput();
        getYear(date);
        getMonth(date/10000);
        //set the day
        date = date/100;
        day = date%100;
        output(date);
    }

    /**
     * GetUserInput - get the input from the user
     * 
     */
    public int getUserInput()
    {
        do
        {
            //Get the date from the user
            Scanner in = new Scanner(System.in);
            System.out.println("Enter a date in MMDDYY format:");
            try
            {
                date = -99;
                String datestr = in.next();
                date = Integer.parseInt(datestr);
            }
            catch(Exception e)
            {
                System.err.println(e);
            }
        }while(date == -99);
        System.out.println("Input:\""+date+"\"");
        return date;
    }
    
    /**
     * Get Month - get the month from the number
     *
     * @param  int date
     * @return     The new date minus the month numbers
     */
    public int getMonth(int date)
    {
        int monthNumeralOne,monthNumeralTwo,imonth;
        //Set the back numeral
        monthNumeralOne = date%10;
        //Set the date - 1 digit
        date = date/10;
        //Set the front numeral
        monthNumeralTwo = date%10;
        //Set the date - 1 digit
        date = date/10;
        
        imonth = monthNumeralTwo*10 + monthNumeralOne;
        
        switch(imonth)
        {
            case 1: month = "Jan"; break;
            case 2: month = "Feb"; break;
            case 3: month = "Mar"; break;
            case 4: month = "Apr"; break;
            case 5: month = "May"; break;
            case 6: month = "Jun"; break;
            case 7: month = "Jul"; break;
            case 8: month = "Aug"; break;
            case 9: month = "Sep"; break;
            case 10: month = "Oct"; break;
            case 11: month = "Nov"; break;
            case 12: month = "Dec"; break;
            default: month = "ERR"; break;
        }
        
        
        return date;
    }
    
    /**
     * Get Year - get the year from the number
     *
     * @param  int date
     * @return     The new date minus the year numbers
     */
    public int getYear(int date)
    {
        int yearNumeralOne,yearNumeralTwo;
        //Set the back numeral
        yearNumeralOne = date%10;
        //Set the date - 1 digit
        date = date/10;
        //Set the front numeral
        yearNumeralTwo = date%10;
        //Set the date - 1 digit
        date = date/10;
        year = yearNumeralTwo*10 + yearNumeralOne;
        
        return date;
    }
    
    /**
     * Output - outputs the date
     * @param  date the day.
     */
    public void output(int date)
    {
        System.out.println();
        System.out.print(day+" "+month+", "+year);
    }
}