
/**
 * Main is the bootstrapper
 * 
 * @author Joseph Lewis
 * @version August 25, 2009
 */
public class Main
{
    public static void main(String[] arguments)
    {
        DateChanger dc = new DateChanger();
        
    }
}
