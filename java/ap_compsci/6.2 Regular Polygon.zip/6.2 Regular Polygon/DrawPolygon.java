
/**
 * Draw Polygon draws the polygon
 * 
 * @author Joseph Lewis
 * @version 9.08
 */

import gpdraw.*;
import java.awt.Color;

public class DrawPolygon 
{

    private DrawingTool     vector;
    private SketchPad       canvas;
    private double          scale;
    private RegularPolygon  rp;
    //Width and height of screen
    private int SCREEN_X = 600;
    private int SCREEN_Y = 600;

    public DrawPolygon (RegularPolygon rpc)
    {
        
        rp = rpc;
        scale = getScale();
        //Draw the objects on screen
        drawObjectsOnScreen();
    }
    
    /**
     * getScale - Get the scale of the project so 
     * pixels can be properly drawn
     * This will put a size to the units passed by
     * the RegularPolygon Class
     * 
     * @return double Scale
     */
    private double getScale()
    {
        //The scale is 500 (The screen size) 
        // divided by the the diamater of the largest circle
        return 500/(rp.getR()*2);
    }
    
    /**
     * drawObjectsOnScreen - Draw the objects on screen
     * 
     */
    private void drawObjectsOnScreen()
    {
        //Get the Screen
        canvas = getCanvas();
        //Get the drawing Tool
        DrawingTool vector = getDrawingTool(canvas);
        //Draw the R circle
        vector.setColor(Color.BLUE);
        vector.drawCircle(rp.getR()*scale);
        
        //Draw the r circle
        vector.drawCircle(rp.getr()*scale);
        
        //Draw the object inside the two circles
        //Reset the drawing tool
        vector = getDrawingTool(canvas); 
        //Dont Draw This
        vector.up();
        
        
        vector.setColor(Color.GREEN);
        //Move NORTH to the edge of the circle
        vector.move(rp.getR()*scale);
        
        //Turn to the proper angle
        vector.turnRight(180 - (rp.vertexAngle()/2));
        
        vector.down();
        for(int i = 1; i<= rp.getNumside(); i++)
        {
            vector.move(rp.getSideLength()*scale);
            vector.turnRight( 180 - rp.vertexAngle());
            
        }
        
    }
    
    /**
     * getCanvas - give the user a canvas to work with
     */
    private SketchPad getCanvas()
    {
        SketchPad sp = new SketchPad(SCREEN_X, SCREEN_Y);
        return sp;
    }
    
    /**
     * getPen - give the user a drawing tool to work with
     */
    private DrawingTool getDrawingTool(SketchPad canvas)
    {
        DrawingTool sp = new DrawingTool(canvas);
        return sp;
    }
}
