
/**
 * Main is the bootstrapper
 * 
 * @author Joseph Lewis
 * @version August 25, 2009
 */
public class Main
{
    public static void main(double[] arguments) 
    {
        RegularPolygon rp;
        
        try
        {
            //Tell the user what they entered
            System.out.println("Calculating:");
            System.out.println("Side = "+arguments[0]);
            System.out.println("Side = "+arguments[1]);
            //Create the program
            rp = new RegularPolygon((int)arguments[0],arguments[1]);
        }
        catch(ArrayIndexOutOfBoundsException ex)
        {
            System.out.println("You Did Not Specify Any Paramaters, Defaulting");
            System.out.println("Paramaters are specified by putting in an array i.e.");
            System.out.println("{3,1} for a Triangle {Sides, Length}");
            rp = new RegularPolygon();
        }
        
        
    }
    public static void main(String[] arguments)
    {
        RegularPolygon rp = new RegularPolygon();
    }
}
