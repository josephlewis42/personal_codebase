
/**
 * Model of a regular polygon
 *
 * @author Joseph Lewis
 * @version 8/25/09
 * @licence gnu gpl 3.0
 */

import java.lang.Integer;//Conversion
import java.lang.Double;//Conversion
import java.lang.Math;//General Mathmatics
import java.util.Scanner;//System.in

public class RegularPolygon
{
    // instance variables - replace the example below with your own
    private int     myNumSides;      // # of sides
    private double  mySideLength;    //Length of side
    private double  myR;            //Radius of circumscribed circle
    private double  myr;            //Radius of inscribed circle
    public boolean tui;            //TRUE if the user wants a text interface only
    
    /**
     * Constructor for objects of class RegularPolygon
     */
    public RegularPolygon()
    {
        //Call the proper constructor
        getUInput();
        
        //Calc and set the two R's
        calcR();
        calcr();
        //Draw the results
        
        DrawPolygon dp = new DrawPolygon(this);
        
        //Print the results
        printer();
        
    }
    
    public RegularPolygon(int numSides, double sideLength)
    {
        myNumSides = numSides;
        mySideLength = sideLength;
        //Calc and set the two R's
        calcR();
        calcr();
        //Draw the results
        
        DrawPolygon dp = new DrawPolygon(this);
        
        //Print the results
        printer();
    }

    /**
     * calcr - Get the radius of the inscribed circle
     * 
     * @return     r
     */
    private void calcr()
    {
        double r;
        
        r = .5*mySideLength*cot(Math.PI/myNumSides);
        
        myr = r;
    }
    
    /**
     * calcR - Get the radius of the circumscribd circle
     * 
     * @return     R
     */
    private void calcR()
    {
        double R;
        R = .5 * mySideLength * (1/Math.sin( Math.PI/myNumSides ));
        myR = R;
    }
    
    /**
     * vertexAngle
     * 
     * @return     
     */
    public double vertexAngle()
    {
       double theta;
       
       theta = (((double)myNumSides - 2)/((double)myNumSides))*180;
       
       return theta;
    }

    
    /**
     * Perimeter
     * 
     * @return     
     */
    public double Perimeter()
    {
        double perim;
        perim = myNumSides * mySideLength;
        return perim;
    }
    
    /**
     * Area
     * 
     * @return    
     */
    public double Area()
    {
        double area;
        
        area = .5 * myNumSides * (myR * myR)*Math.sin((2*Math.PI)/myNumSides);
        
        return area;
    }
    
    /**
     * getNumside
     *
     */
    public double getNumside()
    {
        return myNumSides;
    }
    
    /**
     * getSideLength
     * 
     * @return     the sum of x and y 
     */
    public double getSideLength()
    {
        return mySideLength;
    }
    
    /**
     * getr
     */
    public double getr()
    {
        return myr;
    }
    
    /**
     * getR
     * 
     */
    public double getR()
    {
        return myR;
    }


    
    
    /**
     * Get the cotangent of theta
     */
    public double cot(double theta)
    {
        theta = 1/Math.tan(theta);
        
        return theta;
    }
    
    /**
     * Printer
     */
    public void printer()
    {
        System.err.println(tui);
        if(tui == false)
        {
            Dialogs d = new Dialogs();
            d.showInformationDialog("Output", "n = \t\t"+myNumSides +
                                            "\n" + "s = \t\t"+mySideLength + 
                                            "\n" + "Theta = \t"+vertexAngle() + 
                                            "\n" + "r = \t\t"+myr + 
                                            "\n" + "R = \t\t"+myR + 
                                            "\n" + "Perimeter = \t"+Perimeter() + 
                                            "\n" + "Area = \t\t"+Area());
                                            
        }
        else
        {
            System.out.println("n = \t\t"+myNumSides);
            System.out.println("s = \t\t"+mySideLength);
            System.out.println("Theta = \t"+vertexAngle());
            System.out.println("r = \t\t"+myr);
            System.out.println("R = \t\t"+myR);
            System.out.println("Perimeter = \t"+Perimeter());
            System.out.println("Area = \t\t"+Area());
            System.out.println("\n\n");
        }
    }
    
    /**
     * Ask user input
     */
    public void getUInput ()
    {
        //Read user input
        Scanner in = new Scanner(System.in);
        
        System.out.println("This program will calculate a regular polygon:");
        System.out.println("Please enter the number of sides for the desired polygon:");
        System.out.println("");
        System.out.println("Would you like to use the Graphical User Interface [Y/N]");
        String yn = in.next();
        
        tui = (yn.equals("y")||yn.equals("Y")) ? false : true;

        
        int i = 0;
        do
        {
            Dialogs d = new Dialogs();
            try
            {
                if(tui == false)
                {
                    //Ask for the num of sides
                    String s = d.showUserInputDialog("Hello","Input the number of sides.");
                    myNumSides = Integer.parseInt(s);
                    //ASk for the length of sides
                    s = d.showUserInputDialog("Hello","Input the length of the sides.");
                    mySideLength = Double.parseDouble(s);
                    //Ask to confirm
                    i = d.showYesNoQuestionDialog("Question","Do you want your side length to be: "
                                                    + mySideLength +
                                                    "\nAnd your number of sides to be: "+ myNumSides+"? ");
                }
                
                if(tui == true)
                {
                    
                    System.out.println("Enter the number of sides:");
                    myNumSides = in.nextInt();
                    System.out.println("Enter the length of sides:");
                    mySideLength = in.nextDouble();
                    System.out.println("Do you want your side length to be: "+ mySideLength +
                                        "\nAnd your number of sides to be: "+ myNumSides+"?[Y/N]");
                    yn = in.next();
        
                    if(yn.equals("y")||yn.equals("Y"))
                    {
                        i = 1;
                    }
                }
                 
                
            }
            catch(Exception ex)
            {
                if(tui==false)
                {
                    d.showErrorDialog("Error","Sorry, you entered a bad number try again");
                }
                else
                {
                    System.out.println("Error");
                }
            }
            
        }
        while(i!=1);
        
    }
}
