import java.util.ArrayList;
/**
 * PermutationGenerator creates a random permutation.
 * 
 * @author Joseph Lewis
 * @version October 20, 2009
 */
public class PermutationGenerator
{
    //Used to place the numbers
    ArrayList<String> toFill;
    //Used to take the numbers
    ArrayList<String> toTake;

    /**
     * Constructor for objects of class PermutationGenerator
     */
    public PermutationGenerator()
    {
    }

    /**
     * Next -- Gets a new permutation and prints it.
     * 
     */
    public void next()
    {
        //Clear and reset the new array lists
        toTake = new ArrayList<String>();
        toFill = new ArrayList<String>();
        
        //Set up the array List holding the default values
        toTake.add("  1");
        toTake.add("  2");
        toTake.add("  3");
        toTake.add("  4");
        toTake.add("  5");
        toTake.add("  6");
        toTake.add("  7");
        toTake.add("  8");
        toTake.add("  9");
        toTake.add(" 10");
        
        //Transfer a random value over ten times
        for(int i = 9; i > 0; i--)
        {
            //Choose a random value
            int randomCell = (int)(i*Math.random());
            //Move the value other
            toFill.add(toTake.get(randomCell));
            //Remove the value
            toTake.remove(randomCell);
        }
        
        printIterations(toFill);
    }
    
    /**
     * printMany -- print many permutations
     */
    public void printMany(int num)
    {
        System.out.println("Ranomd Permutation List Generator Output");
        for (int n = 1; n <= num; n ++)
        {
            System.out.print("List " + n + "\t:");
            next();
            System.out.println();
        }
    }
    
    /**
     * printIterations(toFill) -- Prints all the values
     * 
     */
    private void printIterations(ArrayList<String> a)
    {
        
        for(int i = 0; i < a.size(); i++)
        {
            System.out.print(a.get(i));
        }
    }
}
