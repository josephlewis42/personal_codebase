/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Cay Horstmann
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 */

import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.grid.*;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
/**
 * A <code>BoxBug</code> traces out a square "box" of a given size. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class JumperBug extends Bug
{
    /**
     * Constructs a box bug that traces a square of a given side length
     * @param length the side length
     */
    public JumperBug()
    {

    }

    /**
     * Moves to the next location of the square.
     */
    public void act()
    {
        //Get location and direction.
        final Location currentLocation = getLocation();
        final int      direction       = getDirection();
        final Grid grid = getGrid();
        
        //Generate the location of two hops, and one hop
        final int col = currentLocation.getCol();
        final int row = currentLocation.getRow();
        
        //Get new locations
        int oneHopCol = col;
        int oneHopRow = row;
        int twoHopCol = col;
        int twoHopRow = row;
        
        //Use a swtich to check where each row and col should be after one and two hops
        switch (direction)
        {
            case 0 : //NORTH
                oneHopRow -= 1;
                twoHopRow -= 2;
                break;
                
            case 45 : //NORTHEAST
                oneHopCol += 1;
                oneHopRow -= 1;
                twoHopCol += 2;
                twoHopRow -= 2;
                break;
                
            case 90 : //EAST
                oneHopCol += 1;
                twoHopCol += 2;
                break;
                
            case 135 : //SOUTHEAST
                oneHopCol += 1;
                oneHopRow += 1;
                twoHopCol += 2;
                twoHopRow += 2;
                break;
                
            case 180 : //SOUTH
                oneHopRow += 1;
                twoHopRow += 2;
                break;
                
            case 225 : //SOUTHWEST
                oneHopCol -= 1;
                oneHopRow += 1;
                twoHopCol -= 2;
                twoHopRow += 2;
                break;
                
            case 270 : //WEST
                oneHopCol -= 1;
                twoHopCol -= 2;
                break;
                
            case 315 : //NORTHWEST
                oneHopCol -= 1;
                oneHopRow -= 1;
                twoHopCol -= 2;
                twoHopRow -= 2;
                break;
            default:
                break;
            }
        //Set the locations for the tests
        Location twoHops = new Location(twoHopRow, twoHopCol);
        Location oneHop  = new Location(oneHopRow, oneHopCol);
        
        //If two from here is empty go there
        if(grid.isValid(twoHops) && (grid.get(twoHops) == null || grid.get(twoHops) instanceof Flower ))
        {
            grid.remove(twoHops);
            moveTo(twoHops);
            grid.put(new Location(row,col), new Flower(getColor()));
        }
        else
        { 
            //If one is empty, go there
            if(grid.isValid(oneHop) && (grid.get(oneHop) == null || grid.get(oneHop) instanceof Flower ))
            {
                grid.remove(oneHop);
                move();
            }
            else
            {
                //If none is empty, turn
                turn();
            }
        }
    }
}
