import java.io.*;
/**
 * Compact compacts an array removing the zeros
 * 
 * @author Joseph Lewis
 * @version 
 */
public class Compact
{
private int[] intArray;
private int numZeros = 0;

    /**
     * Constructor for objects of class Compact
     */
    public Compact()
    {
        //Read File And Parse To String Array That Parses To Int Array
        intArray = readFile();
        //Print the intArray
        printArray(intArray);
        //Remove Zeros
        intArray = removeZeros(intArray);
        //Print the intArray
        printArray(intArray);
    }
    
    
    /**
     * Parses and Reads The file to an int array
     * 
     * @return     an int array
     */
    public int[] readFile()
    {
        String filePath = "compact.txt";
        String line;
        String[] strTokens = new String[1];
        int[]    intTokens;
        
        //Try file reading
       try
       {
           //set up the file reader with the path of the file
           FileReader fr = new FileReader(filePath);
           //Set up the buffered reader with the file reader
           BufferedReader br = new BufferedReader(fr);
           
               line = br.readLine();
               //Convert to a String Array splitting around two spaces
               strTokens = line.split("  ");
        }
        catch(Exception ex)
        {
            System.out.println("Problem reading file see err printer");
            System.err.println("\n==File Reading Problem==\n"+ex);
        }

        //Set the size of the int array
        intTokens = new int[strTokens.length];
        
        //Fill up the int array with parsed strings
        for(int i = 0; i<strTokens.length; i++)
        {
            intTokens[i] = Integer.parseInt(strTokens[i]);
        }
        return intTokens;
    }
    
    /**
     * Prints the int array
     *
     * @param  toPrint -  the array to print
     */
    public void printArray(int[] toPrint)
    {
        System.out.println("");
        //For each int
        for(int i = 0; i < toPrint.length; i++)
        {
            //Print out as long as it is not in the zeros area
            //Prints all when numZeros = 0
            if(i < toPrint.length - numZeros)
                System.out.print(toPrint[i] + "  ");        
        }
    }
    
    /**
     * Removes the Zeros from the array
     *
     * @param  The array to remove zeros from
     * @return The array from which the zeros have been removed
     */
    public int[] removeZeros(int[] toRemove)
    {
        //Count the number of zeros
        for(int i : toRemove)
        {
            //If zero add to total
            numZeros = (i == 0) ? numZeros + 1 : numZeros;
        }
        
        //Move everything up when a zero is found
        for(int i = 0; i < toRemove.length; i++)
        {
            //If it was a zero and is not where zeros are acceptable
            if(toRemove[i] == 0 && i < toRemove.length - numZeros)
            {
                //Move everything up
                for(int j = i; j<toRemove.length; j++)
                {
                    try
                    {
                        //Replace current num with next
                       toRemove[j] = toRemove[j+1];
                    }
                    catch(IndexOutOfBoundsException ex)
                    {
                        //If next is out of bounds replace it with zero
                        toRemove[j] = 0;
                    }
                }
                //Try again from the beginning, this keeps double zeros 
                //from slipping through the algorithm
                i = 0;
            }
        }
        return toRemove;
    }
}
