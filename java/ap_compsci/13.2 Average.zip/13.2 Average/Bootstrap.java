
/**
 * Bootstraps the program
 * 
 * @author Joseph Lewis
 * @version October 12, 2009
 */
public class Bootstrap
{
    public static void Main(String[] args)
    {
        Average a = new Average();
        a.getAverage();
    }
}
