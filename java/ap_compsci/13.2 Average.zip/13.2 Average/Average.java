
/**
 * Gets the average of a file that has ints on each line
 * 
 * @author Joseph Lewis
 * @version October 12, 2009
 */

import java.io.*; //File Reading

public class Average
{
    // instance variables
    int i; // The number of lines the file has
    
    /**
     * Constructor for objects of class Average
     */
    public Average()
    {
    }

    /**
     * getAverage - gets the average
     * 
     * @return     long that is average 
     */
    public long getAverage()
    {
        //Get the path of the file
        String path = promptFile();
        //Get the average of the file
        long average = readFile(path);
        //Print the average
        System.out.println(average);
        Dialogs d = new Dialogs();
        d.showInformationDialog("Have You Heard The Good News?","Average: "+average);
        System.err.println("Jesus Saves");
        return average;
    }
    
    /**
     * promptFile - asks the user for a file to read
     * 
     * @return     String filepath
     */
    public String promptFile()
    {
        String[] extentions = {"Text Files", ".txt"};
        Dialogs d = new Dialogs();
        //Tell the user how to proceed
        d.showInformationDialog("Question","Please Choose The Location Of The File");
        //Show the question Dialg
        String path = d.showOpenDialog (extentions, "", false, true, true);
        
        return path;
    }
    
    /**
     * readFile - parses the given file
     * 
     * @return     average of ints in file
     */
    public long readFile(String path)
    {
        long total = 0; // The total of the file
        int i;
        String nextLine = "";
        
        try
        {
            //Start the file reader for the document, then buffer it
            FileReader fileReader = new FileReader(path);
            BufferedReader br = new BufferedReader(fileReader);
            //For each line
            for(i = -1; nextLine != null; i++)
            {
                nextLine = br.readLine();
                if(nextLine != null)
                {
                    //Change the string to an int
                    total += Integer.parseInt(nextLine);
                }
            }
            total = total/i;
        }
                
        catch(java.io.FileNotFoundException e){System.err.println("FileNotFound");}
        catch(java.io.IOException e){System.err.println("I/O Error");}
        catch(NullPointerException e){System.err.println("Null Pointer Error");}
        
        return total;
    }
}