import java.util.ArrayList;
import java.io.*;
import java.lang.Math;

/**
 * Statistics - Class for working on ArrayList<String> and doing
 * Statistics on them
 * 
 * @author Joseph Lewis
 * @version October 20, 2009
 */
public class Statistics
{
    public String filePath = "";
    public String[] array;
    public double average, stdDev, mode; 
    
    /**
     * Constructor for objects of class Statistics
     */
    public Statistics()
    {
    }

    /**
    * MethodName - MethodDescription
    */
   public void runStats()
   {
       //Get the Filepath
       filePath = promptFile();
       //Read the file to an arrayList
       array = readFile(filePath);
       //Find The Average
       average = average(array);
       //Find the Standard Deviation
       stdDev = stdDev(array, average);
       //Find the mode
       mode = mode(array);
       //Print it out
       System.out.println("Average: " + average);
       System.out.println("Mode: " + mode);
       System.out.println("Standard Deviation: " + stdDev);
       
   }
    
    /**
     * promptFile - asks the user for a file to read
     * 
     * @return     String filepath
     */
    private String promptFile()
    {
        String[] extentions = {"Text Files", ".txt"};
        Dialogs d = new Dialogs(); 
        //Tell the user how to proceed
        d.showInformationDialog("Question","Please Choose The Location Of The File");
        //Show the question Dialg and get the path
        String path = d.showOpenDialog (extentions, "", false, true, true);
        
        return path;
    }
   
   /**
    * readFile - Reads a file to an array list with each line a string
    * 
    * @param  Path of the file
    * @return ArrayList<String> of lines in the file
    */
   public String[] readFile(String filePath)
   {
       String nextLine = "";
       int numberOfLines = 0;
       
       //Count the number of lines in the file
       try
       {
           //set up the file reader with the path of the file
           FileReader fr = new FileReader(filePath);
           //Set up the buffered reader with the file reader
           BufferedReader br = new BufferedReader(fr);
           
           while(nextLine != null)
           {
               nextLine = br.readLine();
               
               if(nextLine != null)
               {
                    numberOfLines++;
                }
           }
        }
        catch(Exception ex)
        {
            System.out.println("Problem reading file see err printer");
            System.err.println("\n==File Reading Problem==\n"+ex);
        }
        
        //Set up the array with the number of lines
        String[] array = new String[numberOfLines];
        
        
        //Try file reading
       try
       {
           //set up the file reader with the path of the file
           FileReader fr = new FileReader(filePath);
           //Set up the buffered reader with the file reader
           BufferedReader br = new BufferedReader(fr);
           
           
           for(int i = 0; i < numberOfLines; i++)
           {
               array[i] = br.readLine();
           }
        }
        catch(Exception ex)
        {
            System.out.println("Problem reading file see err printer");
            System.err.println("\n==File Reading Problem==\n"+ex);
        }
       
       return array;
   }
    
    /**
     * Find the average of the array list
     * 
     * @param An int array to be averaged
     * @return The Average (Double 2 decimal places)
     */
    private double average(String[] array)
    {
        long runningTotal = 0;
        int numOfInts = 0;
        
        for(String str : array)
        {
            try
            {  
                int parsed = Integer.parseInt(str);
                //Add each value to runningTotal
                runningTotal += parsed;
                //Add one to the number of ints
                numOfInts ++;
            }
            catch(NumberFormatException ex)
            {
                System.err.println(ex);
            }
        }

        double average = runningTotal / (double)numOfInts;
        
        return average;
    }
    
    /**
     * stdDev - Finds the standard deviation of an int array
     * 
     * @param an int array to be stdDeved
     * @return Standard Deviation to two decimal places
     */
    private double stdDev(String[] array, double average)
    {
        double standardDeviation;
        int totalDifferences = 0;
        
        
        //Sum the squre of the differences
        for(int i = 0; i < array.length; i++)
        {
            int x = Integer.parseInt(array[i]);
            //difference = number - average
            x = x - (int)average;
            //Power it
            x = x*x;
            //Add it to the other differences
            totalDifferences += x;
        }

        
        //Then square root it
        standardDeviation = Math.sqrt( totalDifferences / (array.length - 1) );
        
        return standardDeviation;
    }
    
    /**
     * Finds the mode of the list
     * 
     * @param ArrayList<String> to be parsed for ints
     * @return int mode
     */
    private int mode(String[] array)
    {
        //Holds the frequencies of numbers 1 - 100;
        int[] numberFrequencyList = new int[101];
        int mostCommonNumber = 0;
        int highestValue = 0;
        
            //For each string in the array
            for(String str : array)
            {
                int parsed = Integer.parseInt(str);
                //Add one to the cell of the number parsed
                numberFrequencyList[parsed] ++;
            }

        
        //Find the most common
        for(int i = 0 ; i < numberFrequencyList.length; i++)
        {
            //If the number in the cell is higher than highest value
            //i must be the highest number so far
            if(numberFrequencyList[i] > highestValue)
            {
                mostCommonNumber = i;
                highestValue = numberFrequencyList[i];
            }
        }
        
        return mostCommonNumber;
    }
}