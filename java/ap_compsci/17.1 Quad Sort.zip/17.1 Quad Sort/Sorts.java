import java.util.*;
import java.lang.Object;
import java.lang.Comparable;
import java.lang.Integer;
/**
 *  Description of the Class
 *
 * @author     Your Name Here
 * @created    Month Day, Year
 */
public class Sorts{
  private long steps;

  /**
   *  Description of Constructor
   *
   * @param  list  Description of Parameter
   */
  public Sorts(){
    steps = 0;
  }

  /**
   *  Bubble Sort is the slowest but easiest sort The Bubble Sort 
   *  gets its name from the way that the largest items �bubble� 
   *  to the top (end). The procedure goes like this.
   *
   * @param  list  reference to an array of integers to be sorted
   */
  public void bubbleSort(ArrayList <Comparable> list)
  {
      //The number of total comparisons is the size - 1
      final int numOfComparisons = list.size() - 1;
      //The number of comparisons with no chane of number
      int numOkayComparisons = 0;
      
      Object currentNumber;
      Object nextNumber;
      
      do
      {
         //Assume all comparisons are good 
         numOkayComparisons = numOfComparisons;
            
          for(int i = 0; i < numOfComparisons; i++)
            {
              //Increce the number of steps
              steps++;
              
              //If the current number is larger swap them
              if( list.get(i).compareTo(list.get(i + 1)) > 0)
                {
                  //Add the first to after the second
                  list.add(i + 2, list.get(i));
                  //Delete the first
                  list.remove(i);
                  //Tell the sorter it must run again
                  numOkayComparisons--;
                }
            }
        }
        //Done when the number of comparisons is the same as those that passed
        while(numOfComparisons != numOkayComparisons);
  }

  /**
   *  The Selection Sort also makes several passes through the list. 
   *  On each pass, it compares each remaining item to the largest item 
   *  that has been found so far in the pass.At the end of a pass, the 
   *  largest item found is swapped with the last remaining item for 
   *  that pass.Thus, swapping only occurs once for each pass. Reducing 
   *  the number of swaps makes the algorithm more efficient
   *
   * @param  list  reference to an array of integers to be sorted
   */
  public void selectionSort(ArrayList <Comparable> list)
  {
      int maximumNumberYet;
      
      //Get Each Number Once
      for (int outer = 0; outer < list.size() - 1; outer++)
      {
          //Set the default max number (The first var)
          maximumNumberYet = outer;
          //Compare against each above
          for (int inner = outer + 1; inner < list.size(); inner++)
          {
              if (list.get(inner).compareTo(list.get(maximumNumberYet)) > 0) 
              {
                  maximumNumberYet = inner; // a new largest item is found
                }
                steps++;
            }
            //swap list[outer] & list[min]
            Comparable c = list.get(outer);
            list.set(outer, list.get(maximumNumberYet));
            list.set(maximumNumberYet, c);
        }
  }

  /**
   *  An insertion sort grabs a number and inserts it in the right place in 
   *  a list.
   *
   * @param  list  reference to an array of integers to be sorted
   */
  public void insertionSort(ArrayList <Comparable> list)
  {
      //Go through each number once (0 is allready sorted)
      for (int outer = 1; outer < list.size(); outer++)
      {
          int inner = outer;
          Comparable main = list.get(inner);

          // Shift larger values to the right
          while (inner > 0 && list.get(inner - 1).compareTo(main) > 0)
          {
              //Move up
              list.set(inner, list.get(inner - 1));
              inner--;
              //Count steps
              steps++;
            }
            //Place the old one in the proper place
            list.set(inner, main);
        }
  }


 /**
   *  Takes in entire vector, but will merge the following sections
   *  together:  Left sublist from a[first]..a[mid], right sublist from
   *  a[mid+1]..a[last].  Precondition:  each sublist is already in
   *  ascending order
   *
   * @param  a      reference to an array of integers to be sorted
   * @param  first  starting index of range of values to be sorted
   * @param  mid    midpoint index of range of values to be sorted
   * @param  last   last index of range of values to be sorted
   */
  private void merge(ArrayList <Comparable> a, int first, int mid, int last){
    //replace these lines with your code
    System.out.println();
    System.out.println("Merge");
    System.out.println();

  }

  /**
   *  Recursive mergesort of an array of integers
   *
   * @param  a      reference to an array of integers to be sorted
   * @param  first  starting index of range of values to be sorted
   * @param  last   ending index of range of values to be sorted
   */
  public void mergeSort(ArrayList <Comparable> a, int first, int last){
    //replace these lines with your code
    System.out.println();
    System.out.println("Merge Sort");
    System.out.println();
  }

 
  /**
   *  Accessor method to return the current value of steps
   *
   */
  public long getStepCount(){
    return steps;
  }

  /**
   *  Modifier method to set or reset the step count. Usually called
   *  prior to invocation of a sort method.
   *
   * @param  stepCount   value assigned to steps
   */
  public void setStepCount(long stepCount){
    steps = stepCount;
  }
  
   /**
   *  Interchanges two elements in an ArrayList
   *
   * @param  list  reference to an array of integers
   * @param  a     index of integer to be swapped
   * @param  b     index of integer to be swapped
   */
  public void swap(ArrayList <Comparable> list, int a, int b){
    //replace these lines with your code
    System.out.println();
    System.out.println("Swap");
    System.out.println();
  }
}
