
/**
 * Squeeze truncates whitespace in files
 * 
 * @author Joseph Lewis 
 * @version October 14 2009
 */

import java.io.*; //File Reading and Writing

public class Squeeze
{

    /**
     * Constructor for objects of class Squeeze
     */
    public Squeeze()
    {
        
    }

    /**
     * squeezeFile - truncates space at the beginning of lines
     * 
     */
    public void squeezeFile()
    {
        //Get the file path
        String filePath = promptFile();
        //Read the file line by line and send out lines
        parseFile(filePath);
    }
    
    /**
     * promptFile - asks the user for a file to read
     * 
     * @return     String filepath
     */
    private String promptFile()
    {
        String[] extentions = {"Text Files", ".txt"};
        Dialogs d = new Dialogs(); 
        //Tell the user how to proceed
        d.showInformationDialog("Question","Please Choose The Location Of The File");
        //Show the question Dialg and get the path
        String path = d.showOpenDialog (extentions, "", false, true, true);
        
        return path;
    }
    
    /**
     * parseFile takes a file, removes beginning whitespace 
     * and writes it out to the same location in another name
     * 
     */
    private void parseFile(String path)
    {
        String line = ""; //Stores the current lines text
        
        //Create the Reader
        try
        {
            //Start the file reader for the document, then buffer it
            FileReader fileReader = new FileReader(path);
            BufferedReader br = new BufferedReader(fileReader);
            //Start the file writer and then buffer it
            FileWriter out = new FileWriter(path+"output.txt");
            
            while(line != null)
            {
                //Read the line from the file
                line = br.readLine();
                //Replace the whitespace with the numbers
                line = removeBeginningWhitespace(line);
                //Write the line out
                out.write(line,0,line.length());
                //Write a newline character
                out.write("\n",0,1);
                
            }
            //Close the sessions and write the files
            out.close();
            br.close();
            
        }
                
        catch(java.io.FileNotFoundException e){System.err.println("FileNotFound");}
        catch(java.io.IOException e){System.err.println("I/O Error");}
        catch(NullPointerException e){System.err.println("Null Pointer Error");}
    }
    
    /**
     * Remove Beginning Whitespace does exactly what it says
     * @param String
     * @return String with whtespace replaced with the number of spaces originally there
     */
    private String removeBeginningWhitespace(String string)
    {
        int i;
        //Remove and count the whitespace
        for(i = 0; string.startsWith(" "); i++)
        {
            string = string.substring(1);
        }
        //Add the number of spaces to the beginning
        string = i + string;
        return string;
    }
}