
/**
 * Converts arabic numerals to roman numerals or the reverse
 * 
 * @author Joseph Lewis 
 * @version Tuesday, October 6, 2009
 */
public class RomanNumeral
{

    /**
     * Constructor for objects of class RomanNumeral
     */
    public RomanNumeral(){ }

    /**
     * Convert Arabic to Roman Numerals
     *
     * @param  x   The number to convert
     * @return     The converted Roman Number
     */
    public static String toRome(int x)
    {
        String romeNumber = "";
        
        //Get the number in each spot
        int ones    = x % 10;
        int tens    = x % 100 - ones;
        int hundred = x % 1000 - tens - ones;
        int thousand= x / 1000;
        
        //Add an M for every Thousand
        for(int i = 1; i <= thousand; i++)
        {
            romeNumber+="M";
        }
        
        //Do the hundreds place
        switch(hundred)
        {
            case 900:
                romeNumber +="CM";
                break;
            case 800:
                romeNumber +="DCCC";
                break;
            case 700:
                romeNumber +="DCC";
                break;
            case 600:
                romeNumber +="DC";
                break;
            case 500:
                romeNumber +="D";
                break;
            case 400:
                romeNumber +="CD";
                break;
            case 300:
                romeNumber +="CCC";
                break;
            case 200:
                romeNumber +="CC";
                break;
            case 100:
                romeNumber +="C";
                break;
        }
        
        //Do the Tens Place
        switch(tens)
        {
            case 90:
                romeNumber +="XC";
                break;
            case 80:
                romeNumber +="LXXX";
                break;
            case 70:
                romeNumber +="LXX";
                break;
            case 60:
                romeNumber +="LX";
                break;
            case 50:
                romeNumber +="L";
                break;
            case 40:
                romeNumber +="XL";
                break;
            case 30:
                romeNumber +="XXX";
                break;
            case 20:
                romeNumber +="XX";
                break;
            case 10:
                romeNumber +="X";
                break;
        }
        
        //Do the ones place
        switch(ones)
        {
            case 9:
                romeNumber +="IX";
                break;
            case 8:
                romeNumber +="VIII";
                break;
            case 7:
                romeNumber +="VII";
                break;
            case 6:
                romeNumber +="VI";
                break;
            case 5:
                romeNumber +="V";
                break;
            case 4:
                romeNumber +="IV";
                break;
            case 3:
                romeNumber +="III";
                break;
            case 2:
                romeNumber +="II";
                break;
            case 1:
                romeNumber +="I";
                break;
        }
        //Output number
        System.out.println(romeNumber);
        
        return romeNumber;
    }
    
    /**
     * Convert Roman Numerals to Arabic Numerals
     *
     * @param  x   The number to convert
     * @return     The converted Roman Number
     */
    public static int toArabic(String x)
    {
        int arabicNumber = 0;
        int ca = 0; //Used to tell what char the method is at
        
        //Subtract an M for every Thousand but dont count those in
        //The other strings
        for(ca = 0; x.charAt(ca) == 'M' ; ca++)
        {
            arabicNumber +=1000;
        }
        
        //Remove all thousands from the string
        x = x.substring(ca, x.length());
        ca = 0;
        
        //Count the hundreds place if there are hundreds
        if(x.charAt(0) == 'D' || x.charAt(0) == 'C')
        {
            //The total of the roman numerals in the hundreds place
            int total = 0;
            
            //If x starts with C
            if(x.startsWith("C"))
            {
                total = 100;//It equals 100 overwrite total
                ca = 1;     //Count the number of characters to cut off to get to the tens place
            }
            //If x is CC it would have passed number one but also gets in here
            if(x.startsWith("CC"))
            {
                total = 200;
                ca = 2;
            }
            //If x is cc it fails here and must equal 200
            if(x.startsWith("CCC"))
            {
                total = 300;
                ca = 3;
            }
            if(x.startsWith("CD"))
            {
                total = 400;
                ca = 2;
            }
            if(x.startsWith("D"))
            {
                total = 500;
                ca = 1;
            }
            if(x.startsWith("DC"))
            {
                total = 600;
                ca = 2;
            }
            if(x.startsWith("DCC"))
            {
                total = 700;
                ca = 3;
            }
            if(x.startsWith("DCCC"))
            {
                total = 800;
                ca = 4;
            }
            if(x.startsWith("CM"))
            {
                total = 900;
                ca = 2;
            }
            
            arabicNumber += total;
        }
        
        //Remove all hundreds from the string
        //Using the number stored earlier
        x = x.substring(ca, x.length());
        ca = 0;
        
        //Count the tens place if there are tens
        if(x.charAt(0) == 'X' || x.charAt(0) == 'L')
        {
            //The total of the roman numerals in the hundreds place
            int total = 0;
            
            if(x.startsWith("X"))
            {
                total = 10;
                ca = 1;     
            }
            if(x.startsWith("XX"))
            {
                total = 20;
                ca = 2;
            }
            if(x.startsWith("XXX"))
            {
                total = 30;
                ca = 3;
            }
            if(x.startsWith("XL"))
            {
                total = 40;
                ca = 2;
            }
            if(x.startsWith("L"))
            {
                total = 50;
                ca = 1;
            }
            if(x.startsWith("LX"))
            {
                total = 60;
                ca = 2;
            }
            if(x.startsWith("LXX"))
            {
                total = 70;
                ca = 3;
            }
            if(x.startsWith("LXXX"))
            {
                total = 80;
                ca = 4;
            }
            if(x.startsWith("XC"))
            {
                total = 90;
                ca = 2;
            }
            
            arabicNumber += total;
        }

        //Remove all Tens from the string
        //Using the number stored earlier as ca
        x = x.substring(ca, x.length());
 
        //Count the tens place if there are tens
        if(x.charAt(0) == 'I' || x.charAt(0) == 'V')
        {
            //The total of the roman numerals in the hundreds place
            int total = 0;
            
            if(x.startsWith("I"))
            {
                total = 1;
            }
            if(x.startsWith("II"))
            {
                total = 2;
            }
            if(x.startsWith("III"))
            {
                total = 3;
            }
            if(x.startsWith("IV"))
            {
                total = 4;
            }
            if(x.startsWith("V"))
            {
                total = 5;
            }
            if(x.startsWith("VI"))
            {
                total = 6;
            }
            if(x.startsWith("VII"))
            {
                total = 7;
            }
            if(x.startsWith("VIII"))
            {
                total = 8;
            }
            if(x.startsWith("IX"))
            {
                total = 9;
            }
            
            arabicNumber += total;
        }

        //Output number
        System.out.println(arabicNumber);
        
        return arabicNumber;
    }
    
}
