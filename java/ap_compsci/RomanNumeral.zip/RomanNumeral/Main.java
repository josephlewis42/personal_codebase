public class Main
{
    public static void Main(String[] args)
    {
        RomanNumeral.toArabic("XLVI");
        RomanNumeral.toArabic("XCIX");
        RomanNumeral.toArabic("MDCCCXIX");
        RomanNumeral.toArabic("DCXLIX");
        RomanNumeral.toArabic("MCMLXXXIII");
     }
}