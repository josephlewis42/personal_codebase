public class Bootstrapper
{
    public static void Main(String[] args)
    {
        
        SortStep ss = new SortStep();
        ss.sortMenu();
    }
}
