import java.lang.Integer;
/**
 * Digit represents a single digit, an int.
 * 
 * @author Joseph Lewis
 * @version January 6, 2010
 */
public class Digit
{
    private double digit;
    private int base;

    /**
     * Constructor for objects of class Digit
     */
    public Digit()
    {
        digit = 0;
        base = 10;
    }
    public Digit(double myDigit, int myBase)
    {
        digit = myDigit;
        base = myBase;
    }

    /**
     * Increments a value
     * 
     * @return a boolean, true if carry, false if not
     */
    public boolean increment()
    {
        digit += 1.0;
        //If the digit is it's base it is time to carry
        if (digit - base >= 0)
        {
            digit = 0;
            return true;
        }
        return false;
    }
    
    /** 
     * Overrides the default to string method.
     */
    public String toString()
    {
        //int n = (int)digit;
        //System.out.println(n);
        return (int)digit + "";
    }
}