public class Tester
{
    public static void main(String[] args)
    {
        System.out.println("Testing Standard");
        Number n = new Number();
        for(int i = 0; i < 21; i++)
        {
            n.increment();
            n.toString();
        }
        System.out.println("Testing Binary");
        n = new Number(0,2);
        for(int i = 0; i < 21; i++)
        {
            n.increment();
            n.toString();
        }
        System.out.println("Testing Hex");
        n = new Number(0,16);
        for(int i = 0; i < 40; i++)
        {
            n.increment();
            n.toString();
        }
    }
}
