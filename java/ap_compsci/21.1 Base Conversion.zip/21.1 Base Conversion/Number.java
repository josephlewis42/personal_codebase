import java.util.*;

/**
 * Number represents an entire number
 * 
 * @author Joseph Lewis
 * @version January 6, 2010
 * 
 *  Create a toString method and an increment method. These two methods will use the corresponding methods of the digit class to do most of the work for them.
 */

public class Number
{
    private ArrayList<Digit> d = new ArrayList<Digit>();
    private int base;
    /**
     * Constructor for objects of class Number
     */
    public Number()
    {
        d.add(new Digit(0, 10));
        base = 10;
    }
    
    public Number(double myDigit, double myBase)
    {
        //Remove values less than one
        base = (int)myBase;
        int iDigit = (int)myDigit;
        
        //Convert to string
        String sDigit = new String(iDigit + "");
        
        for(int i = 0; i < sDigit.length(); i++)
        {
            d.add(new Digit(myDigit % 10, base));
            myDigit /= 10;
        }
    }
    
    public void increment()
    {
        boolean inc = true;
        //For each digit in the array
        for(int i = 0; i < d.size();i++)
        {
            if(inc)
            {
                //Increment it if inc is true
                inc = d.get(i).increment();
            }
        }
        //If increment is true, and the numbers have run out, add another
        if(inc == true)
        {
            d.add(new Digit(1, base));
        }
    }
    
    public String toString()
    {
        String output = "";
        for(int i = d.size() - 1; i >= 0; i --)
        {
            output += d.get(i).toString() + '|';
        }
        System.out.println(output);
        return output;
    }
}
