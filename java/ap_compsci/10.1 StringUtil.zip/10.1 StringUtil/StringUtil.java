
/**
 * Write a description of class StringUtil here.
 * 
 * @author Joseph Lewis 
 * @version Sep 15, 09
 */
public class StringUtil
{

    /**
     * Constructor for objects of class StringUtil
     */
    public StringUtil()
    {
        atinlay("The quick black dog jumped over the lazy red foxes");
    }

    /**
     * reverse - reverse a string and return it.
     * 
     * @param  String old
     * @return String New 
     */
    public static String reverse(String oldStr)
    {
        //Create Variables
        String newStr = "";
        
        for(int i = oldStr.length()-1; i >= 0; i--)
        {
            //add the first character to the last of the new string (reverse)
            newStr += oldStr.charAt(i);
        }
            
        // return the new String
        return newStr;
    }
    
    /**
     * Compare - compares two strings to see if they are palindromes
     * 
     * @param  String original 
     * @return Boolean true if strings compare
     */
    public static boolean palindrome(String original)
    {
        String reversed;
        
        //Replace all unwanted stuff
        original = original.replace(",","");
        original = original.replace(" ","");
        original = original.replace(".","");
        original = original.replace(";","");
        original = original.replace(":","");
        original = original.replace("\"","");
        original = original.replace("'","");
        original = original.replace("?","");
        original = original.replace("!","");
        original = original.replace("&","");
        original = original.toLowerCase();
        
        //get the reverse
        reversed = reverse(original);
        
        //return true if equal false if not
        return (original.equals(reversed)) ? true : false;
    }
    
    /**
     * igpay atinlay
     * 
     * @param string words to turn into pig latin
     * @return string words turned into pig latin
     */
    public static String atinlay(String mySentence)
    {
        //Creat Variables
        String pigspeak = "";
        String pigSentence = "";
        String[] pigarray = mySentence.split(" ");
        
        //Format Each Word
        for(String currentWord : pigarray)
        {
            String lower = currentWord.toLowerCase();   //lc to speed processing
            int a,e,i,o,u;//lowest index of letter
            int index = 0;                            //The very lowest index
            
            //Find the closest vowel -1 if no vowel
            a = lower.indexOf("a");
            e = lower.indexOf("e");
            i = lower.indexOf("i");
            o = lower.indexOf("o");
            u = lower.indexOf("u");
            
            a = (a == -1)? 100000 : a;
            e = (e == -1)? 100000 : e;
            i = (i == -1)? 100000 : i;
            o = (o == -1)? 100000 : o;
            u = (u == -1)? 100000 : u;
            //Find Lowest True Value
            index = a;
            index = (e < index) ? e : index;
            index = (i < index) ? i : index;
            index = (o < index) ? o : index;
            index = (u < index) ? u : index;
            
            //Assign pigspeak word
            pigspeak = currentWord;
            //Convert word to piglatin
            //No Vowels
            if(index == 100000)
            {
                pigspeak += "ay";
            }
            //Vowel at position 1
            else if(index == 0)
            {
                pigspeak+="yay";
            }
            else if(index >0 && index != 100000)
            {
                //Get from char 0 to index -1
                String start = pigspeak.substring(0,index);
                //Get from index to end
                String end = pigspeak.substring(index);
                
                pigspeak = end + start + "ay";
            }
            
            pigspeak.toLowerCase();
            
            pigSentence += pigspeak+" ";
        }
        
        pigSentence +=".";
        
        //Return The Pig Latin
        return pigspeak;
    }
    
    
    /**
     * Shorthand - converts a string to shorthand
     * 
     * @param  String original 
     * @return Shorthand String
     */
    public static String shorthand(String original)
    {
        String reversed;
        
        //Shorthand is in lowercase
        original.toLowerCase();
        //Replace all unwanted stuff
        original = original.replace("a","");
        original = original.replace("e","");
        original = original.replace("i","");
        original = original.replace("o","");
        original = original.replace("u","");

        //Replace the strings to shorthand
        original = original.replace(" fr "," 4 ");
        original = original.replace(" y "," U ");
        original = original.replace(" t "," 2 ");
        
        return original;
    }
    
    
    
}
