/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 * @author Cay Horstmann
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

/**
 * A <code>QuickCrab</code> looks at a limited set of neighbors when it eats and moves.
 * <br />
 */
public class QuickCrab extends CrabCritter
{
    Random r = new Random();

    public QuickCrab()
    {
        setColor(Color.RED);
    }


    /**
     * @return list of empty locations immediately to the right and to the left
     */
    public ArrayList<Location> getMoveLocations()
    {
        ArrayList<Location> locs = new ArrayList<Location>();
         
        //Get Right
            //Get the location to the right
            Location neighborLoc = getLocation().getAdjacentLocation(getDirection() + Location.RIGHT);
            //If its valid and it is empty continue
            if (getGrid().isValid(neighborLoc) && getGrid().get(neighborLoc) == null)
            {
                Location otherNeighborLoc = neighborLoc.getAdjacentLocation(getDirection() + Location.RIGHT);
                //If its valid and it is empty add it
                if (getGrid().isValid(otherNeighborLoc) && getGrid().get(otherNeighborLoc) == null)
                {
                    locs.add(otherNeighborLoc);
                }
            }
                
        //Get Left
            //Get the location to the left
            neighborLoc = getLocation().getAdjacentLocation(getDirection() + Location.LEFT);
            //If its valid and it is empty continue
            if (getGrid().isValid(neighborLoc) && getGrid().get(neighborLoc) == null)
            {
                Location otherNeighborLoc = neighborLoc.getAdjacentLocation(getDirection() + Location.LEFT);
                //If its valid and it is empty add it
                if (getGrid().isValid(otherNeighborLoc) && getGrid().get(otherNeighborLoc) == null)
                {
                    locs.add(otherNeighborLoc);
                }
            }
            
        return locs;
    }

    /**
     * If the crab critter doesn't move, it randomly turns left or right.
     */
    public Location selectMoveLocation(ArrayList<Location> locs)
    {
        Location loc;
        if(locs.size() > 0)
        {
            if(locs.size() == 1)
            {
                return locs.get(0);
            }
            double r = Math.random();
                int angle;
                if (r < 0.5*locs.size())
                    return locs.get(0);
                else
                    return locs.get(1);
        }
        locs = super.getMoveLocations();
        loc = super.selectMoveLocation(locs);
        return loc;
    }
}