/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Joseph Lewis
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import info.gridworld.actor.Rock;

import java.util.ArrayList;
import java.awt.Color;

/**
 * A <code>BlusterCritter</code> gets shy or brave
 */
public class BlusterCritter extends Critter
{
    int c = 0;
    
    //Num is the nimber of critters before it becomes afraid
    public BlusterCritter(int num)
    {
        c = num;
        setColor(Color.YELLOW);
    }
    
    public void processActors(ArrayList<Actor> actors)
    {
        //Need all of the critters within two steps
        actors = getAllActors();
        int numActors = actors.size() -1; //-1 is for the Bluster Critter
        System.out.println("\n"+numActors +" actors nearby");
        //If it should be afraid
        if(numActors > c)
        {
            setColor(getColor().darker());
        }
        else
        {
            setColor(getColor().brighter());
        }
    }

    /**
     * Turns towards the new location as it moves.
     */
    public void makeMove(Location loc)
    {
        setDirection(getLocation().getDirectionToward(loc));
        super.makeMove(loc);
    }
    
    /**
     * getAll�ctors - Gets the valid actors around the Critter in two
     * steps of any side
     *
     * @return     ArrayList<Actor>
     */
    public ArrayList<Actor> getAllActors()
    {
        ArrayList<Location> allLocations = getGrid().getOccupiedLocations();
        ArrayList<Location> validLocations = new ArrayList<Location>();
        ArrayList<Actor> actors = new ArrayList<Actor>(); //Stores the actors
        //Set the vars for the valid cols and rows
        int leastCol = getLocation().getCol() - 2;
        int mostCol  = getLocation().getCol() + 2;
        int leastRow = getLocation().getRow() - 2;
        int mostRow  = getLocation().getRow() + 2;
        //Now get all actors within range, using a for each and some
        //pretty fancy boolean logic
        for(Location l : allLocations)
        {
            //If in right cols
            if(l.getCol() >= leastCol && l.getCol() <= mostCol)
            {
                if(l.getRow() >= leastRow && l.getRow() <= mostRow)
                {
                    validLocations.add(l);
                }
            }
        }
        //Now assemble a list of the actors in those rows
        for(Location l : validLocations)
        {
            actors.add(getGrid().get(l));
        }
        
        return actors;
    }
    
    
}
