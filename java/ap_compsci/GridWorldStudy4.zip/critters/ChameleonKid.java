/** 
 * Joseph Lewis
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

import java.util.ArrayList;

/**
 * A <code>ChameleonKid</code> takes on the color of front and back 
 * neighboring actors as it moves through the grid. <br />
 */
public class ChameleonKid extends ChameleonCritter
{
    /**
     * Randomly selects a neighbor and changes this critter's color to be the
     * same as that neighbor's. If there are no neighbors, no action is taken.
     */
    public void processActors(ArrayList<Actor> actors)
    {
        int n = actors.size();
        if (n == 0)
        {
            setColor(getColor().darker());
        }
        else
        {
            try
            {
                //Get ahead
                //Get the critters direction
                int turn = getDirection();
                //Get the location in this direction
                Location loc = getLocation().getAdjacentLocation(turn);
                //Get the actor in this location
                Actor ahead = getGrid().get(loc);
                if (ahead != null)
                {
                    actors.add(ahead);
                    setColor(ahead.getColor());
                }
            }catch(Exception ex){}
            try
            {
                //Get behind
                //Get the critters rear direction (180* = HALF_CIRCLE)
                int turn = getDirection()+180;
                //Get the location in this direction
                Location loc = getLocation().getAdjacentLocation(turn);
                //Get the actor in this location
                Actor behind = getGrid().get(loc);
                if (behind != null)
                {
                    actors.add(behind);
                    setColor(behind.getColor());
                }
            }catch(Exception ex){}
        }
    }
}
