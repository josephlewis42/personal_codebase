import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.ArrayList;

/**
 * King crab moves the animals around it away, if it cant, it kills them,
 * friendly fello, eh?
 */
public class KingCrab extends CrabCritter
{
   public KingCrab()
   {
       setColor(Color.BLUE);
   }
   private int runAway(Actor act)
   {
       //Get the location of this animal
       Location thisLoc = act.getLocation();
       //Get the locations avalable for this animal
       ArrayList<Location> locs = getGrid().getEmptyAdjacentLocations(thisLoc);
       //Get the locations all around the KingCrab
       ArrayList<Location> validLocs = getGrid().getValidAdjacentLocations(getLocation());
       //For each location in the locations avalable
       for(Location location :locs)
       {
           for(Location kingLocation : validLocs)
           {
               if(location != kingLocation)
               {
                   act.moveTo(location);
                   return 0;
                }
            }
        }
        act.removeSelfFromGrid();
        return 0;
   }
   
   public void processActors(ArrayList<Actor> actorList)
   {
       //For each actor, move it away
       for (Actor act : actorList)
       {
           runAway(act);
       }
   }
}
