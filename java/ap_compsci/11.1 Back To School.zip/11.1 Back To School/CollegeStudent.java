/**
 * CollegeStudent is a kind of student with variables for college.
 * 
 * @author Joseph Lewis
 * @version Monday, October 12, 2009
 */
public class CollegeStudent extends Student
{
    // instance variables
    private String  major;
    private int     year;

    /**
     * Constructor for objects of class CollegeStudent
     */
    public CollegeStudent(String myName, int myAge, String myGender, 
                           String myIdNum, double myGPA, int myYear, String myMajor)
    {
        super(myName, myAge, myGender, myIdNum, myGPA);
        major = myMajor;
        year = myYear;
    }

    /**
     * Setters and getters
     */
    public void setYear(int y){year = y;}
    public void setMajor(String m){major = m;}
    public int getYear(){return year;}
    public String getMajor(){return major;}
    
    /**
     * toString returns a string of the class
     */
    public String toString()
    {
        return super.toString() + ", Year: " + year + ", Major: " + major;
    }
}
