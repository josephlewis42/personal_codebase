
/**
 * Class Teacher defines a teacher Variable
 * 
 * @author Joseph Lewis
 * @version Monday, October 12, 2009
 */
public class Teacher extends Person
{
    // instance variables
    private String subject;
    private double salary;

    /**
     * Constructor for objects of class Teacher
     */
    public Teacher(String myName, int myAge, String myGender, String mySubject, double mySalary)
    {
        //Construct Person
        super(myName, myAge, myGender);
        salary = mySalary;
        subject = mySubject;
    }
    
    /**
     * Setter and getters
     */
    public void setSubject(String sub)
    {
        subject = sub;
    }
    public String getSubject()
    {
        return subject;
    }
    public void setSalary(double sal)
    {
        salary = sal;
    }
    public double getSalary()
    {
        return salary;
    }
    
    public String toString()
    {
        return super.toString() + ", Salary: " + salary + ", Subject: " + subject;
    }
    
}
