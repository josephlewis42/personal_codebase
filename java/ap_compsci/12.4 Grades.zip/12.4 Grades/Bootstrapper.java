public class Bootstrapper
{
    public static void Main(String[] args)
    {
        Grades gr = new Grades();
        
    }
}
