import java.util.*;


/**
 * Finds if a student is eligible or not for a program
 * 
 * @author Joseph Lewis
 * @version November 20, 2009
 */
public class Grades
{

    private String grades;
    private String[] gradesList;
    private Scanner console;
    private double     average = 0;
    private boolean hasAnF = false;
    
    /**
     * Constructor for objects of class Grades
     */
    public Grades()
    {
        System.out.println("Input Grades:");
        console = new Scanner(System.in);
        
        //Read all grades
        grades = console.nextLine();
        
        grades = grades.toLowerCase();
        
        //Split it
        gradesList = grades.split(" ");
        
        //Check Average Grade
        for(String grade : gradesList)
        {
            average += (grade.equals("a")) ? 4 : 0;
            average += (grade.equals("b")) ? 3 : 0;
            average += (grade.equals("c")) ? 2 : 0;
            average += (grade.equals("d")) ? 1 : 0;
            average += (grade.equals("f")) ? 0 : 0;
            //Return hasAnF if false on this round, memory used here
            hasAnF   = (grade.equals("f")) ? true : hasAnF;
        }
        
        average /= gradesList.length;
        
        if(gradesList.length < 4)
        {
            System.out.println("Ineligible, taking less than 4 classes");
        }
        else
        if(average < 2.0 && hasAnF)
        {
            System.out.println("Ineligible, gpa below 2.0 and has F grade");
        }
        else
        if(average > 2.0 && hasAnF)
        {
            System.out.println("Ineligible, gpa above 2.0 but has F grade (note: gpa >= 2.0)");
        }
        else
        if(average < 2.0)
        {
            System.out.println("Ineligible, gpa below 2.0");
        }
        else
        System.out.println("Eligible");
    }

    
}
