
/**
 * Program gets a code from the plate and creates a car rental code.
 * 
 * @author Joseph Lewis
 * @version October 2 2009
 */

import java.util.Scanner;   //System.in

public class PlateIdentifier
{

    private String make,model,plate,plateID;
    
    /**
     * Constructor for objects of class PlateIdentifier
     */
    public PlateIdentifier()
    {
        questionUser();
        figurePlate();
        printPlate();
    }

    /**
     * QuestionUser gets information from the user
     * 
     */
    private void questionUser()
    {
        //Get the car information
            Scanner in = new Scanner(System.in);
            //Mdke
            System.out.println("Enter the make:");
            make = in.next();
            //Model
            System.out.println("Enter the model:");
            model = in.next();
            //Plate
            System.out.println("Enter the plate (LLL-###):");
            plate = in.next();
    }
    
    /**
     * figurePlate - gets the plate and outputs it
     *
     */
    private void figurePlate()
    {
        //Get the three letters on the plate
        char letter = plate.charAt(0);
        char lettertwo = plate.charAt(1);
        char letterthree = plate.charAt(2);
        //Add the ASCII values of the letters
        int total = (int)letter + (int)lettertwo + (int)letterthree;
        //Add the numbers at the end of the plate to the total
        total += ((int)plate.charAt(4)-48)*100 + ((int)plate.charAt(5)-48)*10 + ((int)plate.charAt(6)-48);

        //Take the remainder of total divided by the num
        //of letters in the alphabet
        int remainder = total % 26;

        //Get the character that is total numbers after the letter A ie (4 = E)
        letter = (char)((int)'A'+remainder);
        
        //Combine the whole thing
        plateID = "";
        plateID+=letter;
        plateID+=total;
    }
    
    /**
     * printPlate - displays the plate
     */
    public void printPlate()
    {
        System.out.println("Plate Information:");
        System.out.println(plate+" = "+plateID);
    }
    
    
}
