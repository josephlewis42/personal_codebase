
Contributors
==============================================

**Boris Gorelik**, from `Procognia Ltd <http://procognia.com>`_, `Blog inthehaystack.com <http://www.inthehaystack.com/>`_, `@boris_gorelik <http://twitter.com/boris_gorelik>`_, Ashdod, Israel.

.. image:: imgs/email_boris.png

**Amit Saha**, `Blog amitksaha.wordpress.com <http://amitksaha.wordpress.com/>`_, `@amitsaha <http://twitter.com/amitsaha>`_, India.

.. image:: imgs/email_amit.png

**Jelle Feringa**, Jelle Feringa, Tu Delft University, Netherlands.

.. image:: imgs/email_jelle.png

**Henrik Rudstrom**, `Blog uniqueidentifier.net <http://uniqueidentifier.net>`_, `@henrk <http://twitter.com/henrk>`_, Rotterdam, Netherlands.

.. image:: imgs/email_henrik.png


